package com.abdm.eua.message;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequestMapping("api/v1/message")
@RestController
@Slf4j
public class Controller {

    private final Repository messageRepository;

    @Autowired
    public Controller(Repository messageRepository) {

        this.messageRepository = messageRepository;

    }

    @PostMapping
    public ResponseEntity<Message> insert(@RequestBody Message message) {

        try {

            Message _message = messageRepository
                    .save(new Message(message.getMessageId(), message.getResponse(), message.getDhpQueryType(), Timestamp.from(ZonedDateTime.now().toInstant())));

            return new ResponseEntity<>(_message, HttpStatus.CREATED);

        } catch (Exception e) {

            log.error(e.toString());

            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }



    @GetMapping
    public ResponseEntity<List<Message>> getAll() {

        List<Message> messages = new ArrayList<Message>();

        try {

            messageRepository.findAll().forEach(messages::add);

            if (messages.isEmpty()) {

                return new ResponseEntity<>(HttpStatus.NO_CONTENT);

            }

            return new ResponseEntity<>(messages, HttpStatus.OK);

        } catch (Exception e) {

            log.error(e.toString());

            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Message>> getMessageById(@PathVariable("id") String message_id, @RequestParam("dhp_query_type") String dhp_query_type) {

        try {

            Optional<Message> message = messageRepository.findByMessageIdAndDhpQueryType(message_id, dhp_query_type);

            if (message.isEmpty()) {

                return new ResponseEntity<>(HttpStatus.NO_CONTENT);

            } else {

                 return new ResponseEntity<>(message, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

}
