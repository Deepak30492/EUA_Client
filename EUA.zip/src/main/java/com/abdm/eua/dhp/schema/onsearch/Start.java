package com.abdm.eua.dhp.schema.onsearch;


public class Start{
    public Time time;
}
