package com.abdm.eua.dhp.schema.init; 
public class Billing{
    public String name;
    public Address address;
    public String email;
    public String phone;
}
