package com.abdm.eua.dhp.schema.oninit;

public class Customer{
    public String id;
    public String cred;
}
