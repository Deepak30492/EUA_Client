package com.abdm.eua.dhp.schema.confirm;

import java.util.Date;

public class State{
    public Descriptor descriptor;
    public Date updated_at;
    public String updated_by;
}
