package com.abdm.eua.dhp.schema.onconfirm;;

public class Descriptor{
    public String name;
    public String code;
}
