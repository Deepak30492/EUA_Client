package com.abdm.eua.dhp.schema.confirm; 
public class Agent{
    public String id;
    public String name;
    public String image;
    public String dob;
    public String gender;
    public String cred;
    public Tags tags;
    public String phone;
    public String email;
}
