package com.abdm.eua.dhp.schema.onselect;

public class Descriptor{
    public String name;
}
