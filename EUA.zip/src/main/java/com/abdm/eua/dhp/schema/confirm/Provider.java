package com.abdm.eua.dhp.schema.confirm; 
public class Provider{
    public String id;
}
