package com.abdm.eua.dhp.schema.confirm; 
public class Message{
    public Order order;
}
