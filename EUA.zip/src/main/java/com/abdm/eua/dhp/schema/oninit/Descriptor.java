package com.abdm.eua.dhp.schema.oninit;

public class Descriptor{
    public String name;
}
