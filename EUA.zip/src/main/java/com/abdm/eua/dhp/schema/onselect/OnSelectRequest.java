package com.abdm.eua.dhp.schema.onselect;

public class OnSelectRequest{
    public Context context;
    public Message message;
}
