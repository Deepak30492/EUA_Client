package com.abdm.eua.dhp.schema.onconfirm;;

public class Time{
    public Range range;
}
