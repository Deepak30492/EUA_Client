package com.abdm.eua.dhp.schema.onsearch;

public class Category{
    public String id;
    public Descriptor descriptor;
}
