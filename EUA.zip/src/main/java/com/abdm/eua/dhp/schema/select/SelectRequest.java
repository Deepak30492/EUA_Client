package com.abdm.eua.dhp.schema.select; 
public class SelectRequest{
    public Context context;
    public Message message;
}
