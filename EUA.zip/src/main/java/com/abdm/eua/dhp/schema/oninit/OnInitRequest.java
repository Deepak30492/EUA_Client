package com.abdm.eua.dhp.schema.oninit;

public class OnInitRequest{
    public Context context;
    public Message message;
}
