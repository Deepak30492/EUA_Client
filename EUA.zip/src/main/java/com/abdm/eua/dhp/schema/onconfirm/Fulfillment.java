package com.abdm.eua.dhp.schema.onconfirm;;

public class Fulfillment{
    public String id;
    public String type;
    public Person person;
    public State state;
    public Time time;
    public Customer customer;
}
