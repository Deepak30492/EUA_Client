package com.abdm.eua.dhp.schema.onstatus;;

public class Billing{
    public String name;
    public Address address;
    public String email;
    public String phone;
}
