package com.abdm.eua.dhp.schema.onsearch;

public class Time{
    public String timestamp;
}
