package com.abdm.eua.dhp.schema.onstatus;;

public class Payment{
    public String uri;
    public String type;
    public String status;
}
