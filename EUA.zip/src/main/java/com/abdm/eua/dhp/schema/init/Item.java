package com.abdm.eua.dhp.schema.init; 
public class Item{
    public String id;
    public String fulfillment_id;
}
