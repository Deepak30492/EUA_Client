package com.abdm.eua.dhp.schema.select;

import java.util.ArrayList;

public class Order{
    public Provider provider;
    public ArrayList<Item> items;
}
