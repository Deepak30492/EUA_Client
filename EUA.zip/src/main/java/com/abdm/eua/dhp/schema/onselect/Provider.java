package com.abdm.eua.dhp.schema.onselect;

public class Provider{
    public String id;
    public Descriptor descriptor;
}
