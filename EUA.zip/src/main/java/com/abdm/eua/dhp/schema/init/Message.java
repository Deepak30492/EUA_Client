package com.abdm.eua.dhp.schema.init; 
public class Message{
    public Order order;
}
