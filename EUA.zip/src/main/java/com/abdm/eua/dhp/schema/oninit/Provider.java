package com.abdm.eua.dhp.schema.oninit;

public class Provider{
    public String id;
    public Descriptor descriptor;
}
