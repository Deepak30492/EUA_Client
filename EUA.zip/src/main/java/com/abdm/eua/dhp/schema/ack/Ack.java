package com.abdm.eua.dhp.schema.ack;

public class Ack{
    public String status;
}
