package com.abdm.eua.dhp.schema.ack;

import com.abdm.eua.dhp.schema.init.Context;

import java.util.Optional;

public class AckResponse {
    public Message message;
    public Error error;
 }
