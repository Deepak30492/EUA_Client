package com.abdm.eua.dhp.schema.onsearch;

public class Fulfillment{
    public String id;
    public String type;
    public Person person;
    public Start start;
    public End end;
}
