package com.abdm.eua.dhp.schema.select; 
public class Message{
    public Order order;
}
