package com.abdm.eua.dhp.schema.onstatus;

import java.util.ArrayList;

public class Price{
    public String currency;
    public String value;
    public ArrayList<Breakup> breakup;
}
