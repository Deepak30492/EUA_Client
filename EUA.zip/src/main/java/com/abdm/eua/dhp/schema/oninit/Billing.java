package com.abdm.eua.dhp.schema.oninit;
public class Billing{
    public String name;
    public Address address;
    public String email;
    public String phone;
}
