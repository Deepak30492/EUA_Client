package com.abdm.eua.dhp.schema.init; 
public class Fulfillment{
    public Customer customer;
}
