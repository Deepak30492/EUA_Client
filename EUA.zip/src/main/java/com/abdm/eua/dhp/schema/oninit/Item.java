package com.abdm.eua.dhp.schema.oninit;

public class Item{
    public String id;
    public Descriptor descriptor;
    public String fulfillment_id;
    public String provider_id;
}
