package com.abdm.eua.dhp.schema.onsearch;

public class Message{
    public Catalog catalog;
}
