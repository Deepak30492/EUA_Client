package com.abdm.eua.dhp.schema.onconfirm;;

public class Range{
    public String start;
    public String end;
}
