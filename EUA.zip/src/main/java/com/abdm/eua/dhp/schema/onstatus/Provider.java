package com.abdm.eua.dhp.schema.onstatus;;

public class Provider{
    public String id;
    public Descriptor descriptor;
}
