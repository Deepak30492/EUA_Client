package com.abdm.eua.dhp.schema.init; 
public class Address{
    public String door;
    public String building;
    public String street;
    public String area_code;
}
