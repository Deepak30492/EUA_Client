package com.abdm.eua.dhp.schema.confirm; 
public class Address{
    public String door;
    public String name;
    public String building;
    public String street;
    public String locality;
    public String ward;
    public String city;
    public String state;
    public String country;
    public String area_code;
}
