package com.abdm.eua.dhp.schema.onstatus;;

public class Time{
    public Range range;
}
