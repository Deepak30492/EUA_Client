package com.abdm.eua.dhp.schema.onconfirm;;

public class State{
    public Descriptor descriptor;
}
