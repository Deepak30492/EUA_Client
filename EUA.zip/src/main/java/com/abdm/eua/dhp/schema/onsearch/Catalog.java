package com.abdm.eua.dhp.schema.onsearch;

import java.util.ArrayList;

public class Catalog{
    public Descriptor descriptor;
    public ArrayList<Provider> providers;
}
