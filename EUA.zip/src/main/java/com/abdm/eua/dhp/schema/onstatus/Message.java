package com.abdm.eua.dhp.schema.onstatus;;

public class Message{
    public Order order;
}
