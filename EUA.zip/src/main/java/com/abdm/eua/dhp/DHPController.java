package com.abdm.eua.dhp;

import com.abdm.eua.dhp.schema.ack.AckResponse;
import com.abdm.eua.dhp.schema.confirm.ConfirmRequest;
import com.abdm.eua.dhp.schema.init.InitRequest;
import com.abdm.eua.dhp.schema.onconfirm.OnConfirmRequest;
import com.abdm.eua.dhp.schema.oninit.OnInitRequest;
import com.abdm.eua.dhp.schema.onsearch.OnSearchRequest;
import com.abdm.eua.dhp.schema.onselect.OnSelectRequest;
import com.abdm.eua.dhp.schema.onstatus.OnStatusRequest;
import com.abdm.eua.dhp.schema.search.SearchRequest;
import com.abdm.eua.dhp.schema.select.SelectRequest;
import com.abdm.eua.dhp.schema.status.StatusRequest;
import com.abdm.eua.message.Message;
import com.abdm.eua.message.Repository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;

import java.net.http.HttpResponse;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.Optional;

@RequestMapping("api/v1/")
@RestController
@Slf4j
public class DHPController {

    private final Repository messageRepository;

    @Value("${abdm.gateway.url}")
    private String abdmGatewayURl;

    @Value("${abdm.registry.url}")
    private String abdmRegistryURl;

    @Value("${abdm.eua.url}")
    private String abdmEUAURl;

    HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .build();

    @Autowired
    public DHPController(Repository messageRepository) {

        this.messageRepository = messageRepository;

        log.info("ABDM Gateway :: " + abdmGatewayURl);

        log.info("ABDM Registry :: " + abdmRegistryURl);

    }

    @PostMapping("/on_search")
    public ResponseEntity<AckResponse> onSearch(@RequestBody OnSearchRequest onRequest) throws Exception{

        log.info("Inside on_search API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Optional<com.abdm.eua.message.Message> messageData = messageRepository.findByMessageIdAndDhpQueryType(requestMessageId, "on_search");

            if (messageData.isEmpty()) {

                String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"400\", \"path\": \"string\", \"message\": \"Message ID not present\" } }";

                AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                com.abdm.eua.message.Message message = messageData.get();

                message.setResponse(onRequestString);

                messageRepository.save(message);

                String onRequestAckJsonString = "{ \"message\": { \"ack\": { \"status\": \"ACK\" } } }";

                AckResponse onSearchAck = objectMapper.readValue(onRequestAckJsonString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/on_select")
    public ResponseEntity<AckResponse> onSelect(@RequestBody OnSelectRequest onRequest) throws Exception{

        log.info("Inside on_select API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Optional<com.abdm.eua.message.Message> messageData = messageRepository.findByMessageIdAndDhpQueryType(requestMessageId, "on_select");

            if (messageData.isEmpty()) {

                String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"400\", \"path\": \"string\", \"message\": \"Message ID not present\" } }";

                AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                com.abdm.eua.message.Message message = messageData.get();

                message.setResponse(onRequestString);

                messageRepository.save(message);

                String onRequestAckJsonString = "{ \"message\": { \"ack\": { \"status\": \"ACK\" } } }";

                AckResponse onSearchAck = objectMapper.readValue(onRequestAckJsonString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/on_init")
    public ResponseEntity<AckResponse> onInit(@RequestBody OnInitRequest onRequest) throws Exception{

        log.info("Inside on_init API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Optional<com.abdm.eua.message.Message> messageData = messageRepository.findByMessageIdAndDhpQueryType(requestMessageId, "on_init");

            if (messageData.isEmpty()) {

                String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"400\", \"path\": \"string\", \"message\": \"Message ID not present\" } }";

                AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                com.abdm.eua.message.Message message = messageData.get();

                message.setResponse(onRequestString);

                messageRepository.save(message);

                String onRequestAckJsonString = "{ \"message\": { \"ack\": { \"status\": \"ACK\" } } }";

                AckResponse onSearchAck = objectMapper.readValue(onRequestAckJsonString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/on_confirm")
    public ResponseEntity<AckResponse> onConfirm(@RequestBody OnConfirmRequest onRequest) throws Exception {

        log.info("Inside on_confirm API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Optional<com.abdm.eua.message.Message> messageData = messageRepository.findByMessageIdAndDhpQueryType(requestMessageId, "on_confirm");

            if (messageData.isEmpty()) {

                String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"400\", \"path\": \"string\", \"message\": \"Message ID not present\" } }";

                AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                com.abdm.eua.message.Message message = messageData.get();

                message.setResponse(onRequestString);

                messageRepository.save(message);

                String onRequestAckJsonString = "{ \"message\": { \"ack\": { \"status\": \"ACK\" } } }";

                AckResponse onSearchAck = objectMapper.readValue(onRequestAckJsonString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/on_status")
    public ResponseEntity<AckResponse> onStatus(@RequestBody OnStatusRequest onRequest) throws Exception{

        log.info("Inside on_status API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Optional<com.abdm.eua.message.Message> messageData = messageRepository.findByMessageIdAndDhpQueryType(requestMessageId, "on_status");

            if (messageData.isEmpty()) {

                String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"400\", \"path\": \"string\", \"message\": \"Message ID not present\" } }";

                AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                com.abdm.eua.message.Message message = messageData.get();

                message.setResponse(onRequestString);

                messageRepository.save(message);

                String onRequestAckJsonString = "{ \"message\": { \"ack\": { \"status\": \"ACK\" } } }";

                AckResponse onSearchAck = objectMapper.readValue(onRequestAckJsonString, AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/search")
    public ResponseEntity<AckResponse> search(@RequestBody SearchRequest onRequest) throws Exception{

        log.info("Inside Search API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            log.info("Gateway URI :: " + abdmGatewayURl);

            onRequest.context.consumer_id = abdmEUAURl;

            onRequest.context.consumer_uri = abdmEUAURl;

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Request Body :" + onRequestString);

            Message _message = messageRepository.save(new Message(requestMessageId, "", "search", Timestamp.from(ZonedDateTime.now().toInstant())));

            log.info("Request Body :" + onRequestString);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(abdmGatewayURl + "/search"))
                    .timeout(Duration.ofMinutes(1))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(onRequestString))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body().toString());

                AckResponse onSearchAck = objectMapper.readValue(response.body(), AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body());

                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/select")
    public ResponseEntity<AckResponse> select(@RequestBody SelectRequest onRequest) throws Exception {

        log.info("Inside select API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            onRequest.context.consumer_id = abdmEUAURl;

            onRequest.context.consumer_uri = abdmEUAURl;

            String providerURI = onRequest.context.provider_uri;

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Provider URI :" + providerURI);

            log.info("Request Body :" + onRequestString);

            Message _message = messageRepository.save(new Message(requestMessageId, "", "select", Timestamp.from(ZonedDateTime.now().toInstant())));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(providerURI + "/select"))
                    .timeout(Duration.ofMinutes(1))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(onRequestString))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body().toString());

                AckResponse onSearchAck = objectMapper.readValue(response.body(), AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body());

                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/init")
    public ResponseEntity<AckResponse> init(@RequestBody InitRequest onRequest) throws Exception{

        log.info("Inside init API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            onRequest.context.consumer_id = abdmEUAURl;

            onRequest.context.consumer_uri = abdmEUAURl;

            String providerURI = onRequest.context.provider_uri;

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Provider URI :" + providerURI);

            log.info("Request Body :" + onRequestString);

            Message _message = messageRepository.save(new Message(requestMessageId, "", "init", Timestamp.from(ZonedDateTime.now().toInstant())));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(providerURI + "/init"))
                    .timeout(Duration.ofMinutes(1))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(onRequestString))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body().toString());

                AckResponse onSearchAck = objectMapper.readValue(response.body(), AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body());

                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/confirm")
    public ResponseEntity<AckResponse> confirm(@RequestBody ConfirmRequest onRequest) throws Exception {

        log.info("Inside confirm API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();
        try {

            onRequest.context.consumer_id = abdmEUAURl;

            onRequest.context.consumer_uri = abdmEUAURl;

            String providerURI = onRequest.context.provider_uri;

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Provider URI :" + providerURI);

            log.info("Request Body :" + onRequestString);

            Message _message = messageRepository.save(new Message(requestMessageId, "", "confirm", Timestamp.from(ZonedDateTime.now().toInstant())));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(providerURI + "/confirm"))
                    .timeout(Duration.ofMinutes(1))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(onRequestString))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body().toString());

                AckResponse onSearchAck = objectMapper.readValue(response.body(), AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body());

                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    @PostMapping("/status")
    public ResponseEntity<AckResponse> status(@RequestBody StatusRequest onRequest) throws Exception{

        log.info("Inside status API ");

        ObjectWriter ow = new ObjectMapper().writer();

        ObjectMapper objectMapper = new ObjectMapper();

        try {

            onRequest.context.consumer_id = abdmEUAURl;

            onRequest.context.consumer_uri = abdmEUAURl;

            String providerURI = onRequest.context.provider_uri;

            String onRequestString = ow.writeValueAsString(onRequest);

            String requestMessageId = onRequest.context.message_id;

            log.info("Provider URI :" + providerURI);

            log.info("Request Body :" + onRequestString);

            Message _message = messageRepository.save(new Message(requestMessageId, "", "status", Timestamp.from(ZonedDateTime.now().toInstant())));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(providerURI + "/status"))
                    .timeout(Duration.ofMinutes(1))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(onRequestString))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body().toString());

                AckResponse onSearchAck = objectMapper.readValue(response.body(), AckResponse.class);

                return new ResponseEntity<>(onSearchAck, HttpStatus.OK);

            } else {

                System.out.println("Gateway Search Status Code : " + response.statusCode());

                System.out.println("Gateway Search Response body : " + response.body());

                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (Exception e) {

            log.error(e.toString());

            String onSearchAckJsonErrorString = "{ \"message\": { \"ack\": { \"status\": \"NACK\" } }, \"error\": { \"type\": \"\", \"code\": \"500\", \"path\": \"string\", \"message\": \"Something went wrong\" } }";

            AckResponse onSearchAck = objectMapper.readValue(onSearchAckJsonErrorString, AckResponse.class);

            return new ResponseEntity<>(onSearchAck, HttpStatus.INTERNAL_SERVER_ERROR);


        }

    }


}
