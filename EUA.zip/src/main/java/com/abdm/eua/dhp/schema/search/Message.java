package com.abdm.eua.dhp.schema.search; 
public class Message{
    public Intent intent;
}
