package com.abdm.eua.dhp.schema.confirm; 
public class Organization{
    public String name;
    public String cred;
}
