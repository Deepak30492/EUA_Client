package com.abdm.eua.dhp.schema.confirm;

import java.util.ArrayList;
import java.util.Date;
public class Schedule{
    public String frequency;
    public ArrayList<Date> holidays;
    public ArrayList<Date> times;
}
