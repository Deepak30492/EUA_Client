package com.abdm.eua.dhp.schema.search; 
public class Intent{
    public Item item;
}
