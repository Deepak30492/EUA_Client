package com.abdm.eua.dhp.schema.onstatus;;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Tags{
    @JsonProperty("./dhp-0_7_1.teleconf_url") 
    public String dhp071TeleconfUrl;
}
