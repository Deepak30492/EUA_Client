package com.abdm.eua.dhp.schema.confirm;

import java.util.Date;

public class Billing{
    public String name;
    public Organization organization;
    public Address address;
    public String email;
    public String phone;
    public Time time;
    public String tax_number;
    public Date created_at;
    public Date updated_at;
}
