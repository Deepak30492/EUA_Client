package com.abdm.eua.dhp.schema.confirm; 
public class Customer{
    public Person person;
    public Contact contact;
}
