package com.abdm.eua.dhp.schema.onconfirm;

public class OnConfirmRequest{
    public Context context;
    public Message message;
}
