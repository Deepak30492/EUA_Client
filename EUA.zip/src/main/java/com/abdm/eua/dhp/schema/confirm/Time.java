package com.abdm.eua.dhp.schema.confirm;

import java.util.Date;

public class Time{
    public String label;
    public Date timestamp;
    public String duration;
    public Range range;
    public String days;
    public Schedule schedule;
}
