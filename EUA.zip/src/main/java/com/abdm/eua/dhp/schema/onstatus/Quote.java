package com.abdm.eua.dhp.schema.onstatus;;

public class Quote{
    public Price price;
}
