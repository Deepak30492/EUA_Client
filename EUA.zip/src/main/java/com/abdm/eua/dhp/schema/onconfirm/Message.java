package com.abdm.eua.dhp.schema.onconfirm;;
public class Message{
    public Order order;
}
