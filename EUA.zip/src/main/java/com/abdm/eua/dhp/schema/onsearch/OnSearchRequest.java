package com.abdm.eua.dhp.schema.onsearch;

public class OnSearchRequest {
    public Context context;
    public Message message;
}
