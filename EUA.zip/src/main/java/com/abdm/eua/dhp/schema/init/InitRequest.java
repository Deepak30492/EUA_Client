package com.abdm.eua.dhp.schema.init; 
public class InitRequest{
    public Context context;
    public Message message;
}
