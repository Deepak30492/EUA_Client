package com.abdm.eua.dhp.schema.confirm; 
public class Quantity{
    public int count;
    public Measure measure;
}
