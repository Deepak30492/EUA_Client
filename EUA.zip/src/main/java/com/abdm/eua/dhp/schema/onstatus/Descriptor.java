package com.abdm.eua.dhp.schema.onstatus;;

public class Descriptor{
    public String name;
    public String code;
}
