package com.abdm.eua.dhp.schema.confirm; 
public class ConfirmRequest{
    public Context context;
    public Message message;
}
