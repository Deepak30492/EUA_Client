package com.abdm.eua.dhp.schema.onstatus;;

public class Range{
    public String start;
    public String end;
}
