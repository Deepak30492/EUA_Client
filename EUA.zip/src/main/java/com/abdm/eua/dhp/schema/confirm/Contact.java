package com.abdm.eua.dhp.schema.confirm; 
public class Contact{
    public String phone;
    public String email;
    public Tags tags;
}
