package com.abdm.eua.dhp.schema.confirm; 
public class Item{
    public String id;
    public Quantity quantity;
    public String fulfillment_id;
}
