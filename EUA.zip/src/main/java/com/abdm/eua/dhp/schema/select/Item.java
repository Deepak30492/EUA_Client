package com.abdm.eua.dhp.schema.select; 
public class Item{
    public String id;
    public String fulfillment_id;
}
