package com.abdm.eua.dhp.schema.select; 
public class Provider{
    public String id;
}
