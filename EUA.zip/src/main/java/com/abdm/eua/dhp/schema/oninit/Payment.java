package com.abdm.eua.dhp.schema.oninit;

public class Payment{
    public String uri;
    public String type;
    public String status;
}
