package com.abdm.eua.dhp.schema.oninit;

public class Range{
    public String start;
    public String end;
}
