package com.abdm.eua.dhp.schema.oninit;

public class Fulfillment{
    public String id;
    public String type;
    public Person person;
    public Time time;
    public Customer customer;
}
