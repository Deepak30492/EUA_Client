package com.abdm.eua.dhp.schema.onselect;

public class Range{
    public String start;
    public String end;
}
