package com.abdm.eua.dhp.schema.init; 
public class Customer{
    public String id;
    public String cred;
}
