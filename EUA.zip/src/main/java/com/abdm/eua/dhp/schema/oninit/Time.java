package com.abdm.eua.dhp.schema.oninit;

public class Time{
    public Range range;
}
