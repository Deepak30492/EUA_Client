package com.abdm.eua.dhp.schema.status; 
public class Message{
    public String order_id;
}
