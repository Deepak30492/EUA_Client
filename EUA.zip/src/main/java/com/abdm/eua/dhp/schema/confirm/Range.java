package com.abdm.eua.dhp.schema.confirm;

import java.util.Date;

public class Range{
    public int min;
    public int max;
    public Date start;
    public Date end;
}
