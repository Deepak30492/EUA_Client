package com.abdm.eua.dhp.schema.onsearch;

public class End{
    public Time time;
}
