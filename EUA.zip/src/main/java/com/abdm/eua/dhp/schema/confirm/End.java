package com.abdm.eua.dhp.schema.confirm; 
public class End{
    public Time time;
    public Instructions instructions;
    public Contact contact;
    public Person person;
}
