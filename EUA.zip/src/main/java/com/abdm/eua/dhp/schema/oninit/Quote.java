package com.abdm.eua.dhp.schema.oninit;

public class Quote{
    public Price price;
}
