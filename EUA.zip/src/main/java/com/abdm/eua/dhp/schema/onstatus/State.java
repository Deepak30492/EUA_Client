package com.abdm.eua.dhp.schema.onstatus;;

public class State{
    public Descriptor descriptor;
}
