package com.abdm.eua.dhp.schema.search; 
public class Descriptor{
    public String name;
}
