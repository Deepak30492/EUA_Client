package com.abdm.eua.dhp.schema.ack;

public class Message{
    public Ack ack;
}
