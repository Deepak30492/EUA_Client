package com.abdm.eua.dhp.schema.onselect;

public class Message{
    public Order order;
}
