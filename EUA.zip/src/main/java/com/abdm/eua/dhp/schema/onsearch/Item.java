package com.abdm.eua.dhp.schema.onsearch;

public class Item{
    public String id;
    public Descriptor descriptor;
    public String category_id;
    public String fulfillment_id;
}
