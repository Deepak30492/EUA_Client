package com.abdm.eua.dhp.schema.onselect;

public class Quote{
    public Price price;
}
