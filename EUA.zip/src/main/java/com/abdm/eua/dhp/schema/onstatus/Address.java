package com.abdm.eua.dhp.schema.onstatus;;

public class Address{
    public String door;
    public String building;
    public String street;
    public String area_code;
}
