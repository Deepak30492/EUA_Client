package com.abdm.eua.dhp.schema.oninit;

public class Message{
    public Order order;
}
