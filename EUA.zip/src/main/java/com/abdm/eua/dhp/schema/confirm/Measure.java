package com.abdm.eua.dhp.schema.confirm; 
public class Measure{
    public String type;
    public int value;
    public int estimated_value;
    public int computed_value;
    public Range range;
    public String unit;
}
