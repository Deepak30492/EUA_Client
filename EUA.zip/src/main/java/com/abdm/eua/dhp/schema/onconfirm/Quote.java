package com.abdm.eua.dhp.schema.onconfirm;;

public class Quote{
    public Price price;
}
