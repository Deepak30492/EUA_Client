package com.abdm.eua.dhp.schema.search; 
public class Item{
    public Descriptor descriptor;
}
