package com.abdm.eua.dhp.schema.search; 
public class SearchRequest{
    public Context context;
    public Message message;
}
