package com.abdm.eua.dhp.schema.status; 
public class StatusRequest{
    public Context context;
    public Message message;
}
