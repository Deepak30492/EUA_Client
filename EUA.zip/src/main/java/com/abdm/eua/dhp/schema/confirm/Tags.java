package com.abdm.eua.dhp.schema.confirm; 
public class Tags{
    public String additionalProp1;
    public String additionalProp2;
    public String additionalProp3;
}
