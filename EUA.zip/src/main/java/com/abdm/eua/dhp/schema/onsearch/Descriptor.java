package com.abdm.eua.dhp.schema.onsearch;

public class Descriptor{
    public String name;
}
