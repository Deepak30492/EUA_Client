package com.abdm.eua.dhp.schema.onsearch;

public class Person{
    public String id;
    public String name;
    public String gender;
    public String image;
    public String cred;
}
