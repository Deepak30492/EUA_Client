package com.abdm.eua.dhp.schema.onselect;

public class Time{
    public Range range;
}
