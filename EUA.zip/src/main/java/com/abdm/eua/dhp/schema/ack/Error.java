package com.abdm.eua.dhp.schema.ack;

import java.util.Optional;

public class Error {
    public String type;
    public String code;
    public String path;
    public String message;
}
