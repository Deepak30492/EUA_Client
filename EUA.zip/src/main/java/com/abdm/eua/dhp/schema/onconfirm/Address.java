package com.abdm.eua.dhp.schema.onconfirm;;

public class Address{
    public String door;
    public String building;
    public String street;
    public String area_code;
}
