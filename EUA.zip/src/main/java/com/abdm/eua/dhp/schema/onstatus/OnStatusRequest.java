package com.abdm.eua.dhp.schema.onstatus;;
public class OnStatusRequest{
    public Context context;
    public Message message;
}
