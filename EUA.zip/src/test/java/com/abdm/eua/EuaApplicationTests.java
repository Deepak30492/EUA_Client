/*
package com.abdm.eua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EuaApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
